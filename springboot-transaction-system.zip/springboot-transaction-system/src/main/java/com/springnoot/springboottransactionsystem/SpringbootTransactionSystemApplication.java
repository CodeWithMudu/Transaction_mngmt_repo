package com.springnoot.springboottransactionsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTransactionSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTransactionSystemApplication.class, args);
	}

}
