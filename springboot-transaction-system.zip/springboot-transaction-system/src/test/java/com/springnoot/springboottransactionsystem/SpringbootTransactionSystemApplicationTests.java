package com.springnoot.springboottransactionsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootTransactionSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
